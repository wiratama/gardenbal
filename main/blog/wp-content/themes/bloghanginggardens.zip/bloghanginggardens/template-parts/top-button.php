	<div class="front-button hidden-xs">
		<a href="<?php the_field('url_booking' , 'option'); ?>" target="_blank"><h1>BOOK NOW</h1></a>
		<a href="<?php the_field('url_contact' , 'option'); ?>"><h2>CONTACT US</h2></a>
	</div>