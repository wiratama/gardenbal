				<div id="carousel-banner" class="carousel slide" data-ride="carousel">
					<div class="carousel-inner">
						<div class="item active">
							<img src="images/img-1.jpg" alt="First slide">
						</div>
					</div>
				</div>